System map provided by City of Ottawa - 2020

» System Map
OC Transpo operates ~126 different bus routes plus 2 LRT Lines -- and the system map(pdf) shows them all, except for the 600-series school routes.

System Map (pdf) - There are two system maps pdf's in the 2020 folder. One map shows a detour while the City of Ottawa was doing construction. The GIS files generated from the GTFS refelcts the second pdf that does not represent the detour.  


» GTFS was produced by the City of Ottawa.  

The System Map and routes were produced from the GTFS using ArcGIS Pro.  Any topological errors or misalignments have not been corrected from the raw GTFS data.

System map symboloby of routes can be imported using the SYSTEM_MAP_2020.lrx file and the 'Apply Symbology From a Layer tool' in ArcGIS Pro.  



» After the opening of O-Train LRT Line 1, there has been ongoing reliability issues. To resolve the reliability issues, OC Transpo agreed to shut down O-Train Line 1 on certain days in 2020 at the request of Rideau Transit Group/Rideau Transit Maintenance (or "RTG/RTM," the organization in the Public Private Partnership that built and maintain the LRT system -- https://rtg-rtm.com/en/).

As a result, replacement bus service, known as Route R1 was implemented. Route R1 in also known internally as "Route 701". Route R1 operates whenever there is a service disruption to O-Train Line 1, planned or unplanned.

» Route 701 is the replacement bus route for LRT/O-Train Line 2. Line 2 was shut-down for major construction repairs on the line. 